package com.cbp.springbootproject2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication(scanBasePackages = {"com.cbp"})
public class SpringBootProject2Application {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootProject2Application.class, args);
    }

}
