package com.cbp.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.cbp.beans.Student;
import com.cbp.beans.StudentRegistration;



@RestController
public class StudentUpdateController {
    @PutMapping("/update/student")
    public String updateStudentRecord(@RequestBody Student stdn) {
        System.out.println("In updateStudentRecord");
        return StudentRegistration.getInstance().updateStudent(stdn);
    }
}
