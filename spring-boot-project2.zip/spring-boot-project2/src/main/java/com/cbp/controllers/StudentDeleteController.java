package com.cbp.controllers;



import org.springframework.web.bind.annotation.*;

import com.cbp.beans.StudentRegistration;

@RestController
public class StudentDeleteController {

    @DeleteMapping("/delete/student/{regdNum}")
    public String deleteStudentRecord(@PathVariable("regdNum") String regdNum) {

        System.out.println("In deleteStudentRecord");
        return StudentRegistration.getInstance().deleteStudent(regdNum);
    }
}

