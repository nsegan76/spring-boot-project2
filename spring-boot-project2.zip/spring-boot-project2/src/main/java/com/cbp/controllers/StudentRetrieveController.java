package com.cbp.controllers;

// import org.springframework.stereotype.Controller;
import com.cbp.beans.Greeting;
import org.springframework.web.bind.annotation.*;
// import org.springframework.web.bind.annotation.RequestMethod;

import com.cbp.beans.Student;
import com.cbp.beans.StudentRegistration;

import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

@RestController
public class StudentRetrieveController {

    @GetMapping("/student/allstudent")
    public List<Student> getAllStudents() {
        return StudentRegistration.getInstance().getStudentRecords();
    }

}
