package gov.cbp.security.controller;

import java.security.Principal;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller that returns authenticated user information
 * @author Ramesh
 *
 */
@RestController
public class UserController {
	/**
	 * UserInfo endpoint, called from resourceserver(s) 
	 * to validate access_token
	 * @param user
	 * @return
	 */
	@RequestMapping("/validateUser")
	public Principal user(Principal user) {
		return user;
	}
}
