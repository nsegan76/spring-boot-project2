package gov.cbp.security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;

/**
 * oauth2 Authorization server that handles client application
 * authentication and issues access_token. It supports client_credentials
 * grant type that is suitable for server-2-server applications. It also 
 * validates the tokens before a resource is accessed. 
 * Client details and access_tokens are persisted in database and it 
 * uses jdbc ClientDetials and TokenStore
 * 
 * @author Ramesh
 *
 */
@EnableResourceServer
@SpringBootApplication(exclude = {SecurityAutoConfiguration.class})
public class AuthApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthApplication.class, args);
	}
	
}