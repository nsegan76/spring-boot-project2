package com.cbp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.web.client.RestTemplate;

/**
 * Spring oauth2 client application,
 * that uses oauth2RestTemplate for service calls.
 * Authorization is built into it
 * 		- first gets access_token
 * 		- passes above token along with service calls 
 * @author Ramesh
 *
 */
@SpringBootApplication
public class ClientApplication implements CommandLineRunner{
	private final Logger logger = LoggerFactory.getLogger(ClientApplication.class);
	
//	@Value("#{ @environment['authclient.baseUrl'] }")
	@Value("${authclient.baseUrl}")
    private String serverBaseUrl;
	
	public static void main(String[] args) {
        SpringApplication.run(ClientApplication.class, args);
    }
	
	@Bean
    @ConfigurationProperties("authclient.oauth2.client")
    protected ClientCredentialsResourceDetails oAuthDetails() {
        return new ClientCredentialsResourceDetails();
    }
	
	@Bean
    protected RestTemplate restTemplate() {
		return new OAuth2RestTemplate(oAuthDetails());
    }
	
	@Override
    public void run(String... args) {
        logger.info("Result: {}", restTemplate().getForObject(serverBaseUrl + "/res/test", String.class));
    }
}
