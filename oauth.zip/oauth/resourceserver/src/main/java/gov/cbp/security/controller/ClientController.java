package gov.cbp.security.controller;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import gov.cbp.security.entity.Client;
import gov.cbp.security.entity.ClientRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
public class ClientController {
	@Autowired
	private ClientRepository clientRepository;
	
	@GetMapping("clients")
	public List<Client> retrieveAllClients() {
		return clientRepository.findAll();
	}
	
	@GetMapping("/clients/{id}")
	public Client retrieveClient(@PathVariable String id) {
		Optional<Client> client = clientRepository.findById(id);

		if (!client.isPresent())
			//throw new RuntimeException("id-" + id);
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, 
					"id - " + id + " not found");

		return client.get();
	}
	
	@DeleteMapping("/clients/{id}")
	public void deleteClient(@PathVariable String id) {
		clientRepository.deleteById(id);
	}
	
	@PostMapping("/clients")
	public ResponseEntity<Object> createClient(@RequestBody Client client) {
		Client savedClient = clientRepository.save(client);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(savedClient.getClientId()).toUri();

		return ResponseEntity.created(location).build();

	}
	
	@PutMapping("/clients/{id}")
	public ResponseEntity<Object> updateStudent(@RequestBody Client client, 
			@PathVariable String id) {

		Optional<Client> clientOptional = clientRepository.findById(id);

		if (!clientOptional.isPresent())
			return ResponseEntity.notFound().build();

		client.setClientId(id);		
		clientRepository.save(client);

		return ResponseEntity.noContent().build();
	}
}
