package gov.cbp.security.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;


@Entity
@Table(name="oauth_client_details")
@Data
public class Client {
	@Id
	private String clientId;
	//private String name;
	
	private String clientSecret;
	private String scope;
	private String authorizedGrantTypes;
	private String authorities;
	
	public Client(){
		
	}
}
