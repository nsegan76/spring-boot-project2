package gov.cbp.security.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.configurers.oauth2.client.OAuth2LoginConfigurer.UserInfoEndpointConfig;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.token.RemoteTokenServices;
import org.springframework.boot.autoconfigure.security.oauth2.resource.UserInfoTokenServices;

@Configuration
@EnableResourceServer
public class ResourceSecurityConfig extends ResourceServerConfigurerAdapter {
	@Autowired
    private Environment env;
	
    @Override
    public void configure(ResourceServerSecurityConfigurer resources)
            throws Exception {
        resources.resourceId("resource");
    }
    
//    @Bean
//    public RemoteTokenServices LocalTokenService() {
//        final RemoteTokenServices tokenService = new RemoteTokenServices();
//        tokenService.setCheckTokenEndpointUrl(env.getProperty("security.oauth2.resource.userInfoUri"));
//        tokenService.setClientId(env.getProperty("security.oauth2.resource.clientId"));
//        tokenService.setClientSecret(env.getProperty("security.oauth2.resource.clientSecret"));
//        return tokenService;
//    }
    
    @Bean
    public UserInfoTokenServices  userTokenService() {
        final UserInfoTokenServices tokenService = 
        		new UserInfoTokenServices(env.getProperty("security.oauth2.resource.userInfoUri"),
        		"Bearer");
        return tokenService;
    }

}
