package gov.cbp.security.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Sample controller
 * @author Ramesh
 *
 */
@RestController
public class TestController {

//	@PreAuthorize("#oauth2.hasScope('clientA')")
	@PreAuthorize("hasAuthority('ADMIN')")
	@RequestMapping("/test")	
	public String test() {
		return "Hello World test for clientA";
	}
}